# Problem# 1: 
# A split-plot design was conducted considering tree blocks, three levels/treatments of variety in the main plot, and five levels/treatments of nitrogen in the split-plot. Afterward, the yield of certain plant characteristics was observed. The data regarding this experiment were given in the file “Split_Plot_Design”.  Answer the following question using this data. 
# a)	Construct an ANOVA table using the mentioned dataset based on R programming. 
# b)	Write down the null hypothesis of all possible effects and interpret the results based on the ANOVA table. 
# c)	Perform a post-hoc test for the interaction effect (variety × nitrogen) and draw a bar diagram with lettering. 
# 
# Problem# 2: 
# a)	What is principal component analysis? 
# b)	What are the main purposes of principle component analysis in your study area?
# c)	Compute the eigenvalue and eigenvector using the iris data based on R programming.
# d)	Construct a scree plot and interpret how many principal components should be retained to interpret the iris dataset.   
# e)	Construct a bi-plot for the iris data based on R programming and interpret the results.  



# Solution 01:
# a)	Construction of an ANOVA table using the mentioned dataset based on R programming is given below:
# Code 
data<-read.csv("Split_Plot_Design.csv")
attach(data)
dim(data)

blk<-c("Block1","Block2","Block3")
variety<-c("variety1","variety2","variety3")
nitrogen<-c("Nitrogen1","Nitrogen2","Nitrogen3","Nitrogen4","Nitrogen5")

b<-length(blk)
v<-length(variety)
n<-length(nitrogen)

block<-gl(b,v*n,b*v*n,factor(blk))
vari.fact<-gl(v,n,b*v*n,factor(variety))
nitro.fact<-gl(n,1,b*v*n,factor(nitrogen))

library(agricolae)

ANOVA.Fact<-aov(YIELD~vari.fact+nitro.fact+block+vari.fact*nitro.fact,data = data)
summary(ANOVA.Fact)





#c)	Perform a post-hoc test for the interaction effect (variety × nitrogen) and draw a bar diagram with lettering. 

# Code
Post.Hoc.Test<-with(data,HSD.test(YIELD,vari.fact:nitro.fact,DFerror = 28,MSerror = 0.044))

Mean.matrix<-Post.Hoc.Test$means

Mean.matrix<-Mean.matrix[order(Mean.matrix$YIELD,decreasing = TRUE),]
Mu_Tret<-Mean.matrix$YIELD
SE_Treat<-Mean.matrix$std/sqrt(Mean.matrix$YIELD)

Bar.Plot <- barplot2(Mu_Tret, names.arg = rownames(Mean.matrix),
                     xlab = "Treatment Combinations",
                     ylab = "Mean Yield", plot.ci = TRUE,
                     ci.l = Mu_Tret - SE_Treat, ci.u = Mu_Tret + SE_Treat,
                     col = "green", las = 2)

letters <- c("a", "ab", "ab", "bc", "bc", "bc", "c", "cd", "de", 
             "e", "e", "e", "f", "f", "f")

text(x = Bar.Plot, y = Mu_Tret + SE_Treat + 0.1, labels = letters, cex = 0.8)





#Solution 02:

# c) Computation of the the eigenvalue and eigenvector using the iris data based on R programming is given below- 

## Code
# Load the data
iris_data <- read.csv("iris_Data.csv")
# Extract numerical columns (exclude the species column)
numeric_data <- iris_data[, 1:4]
# Compute the covariance matrix
cov_matrix <- cov(numeric_data)
# Compute eigenvalues and eigenvectors
eigen_results <- eigen(cov_matrix)

# Display the eigenvalues
cat("Eigenvalues:\n")
print(eigen_results$values)

# Display the eigenvectors
cat("\nEigenvectors:\n")
print(eigen_results$vectors)





# d) Construction of a scree plot and interpretation of how many principle components should be retained to interpret the iris dataset is given below: 
## Code
# Load the data
iris_data <- read.csv("iris_Data.csv")

# Extract numerical columns (exclude the species column)
numeric_data <- iris_data[, 1:4]
# Perform PCA
pca_result <- prcomp(numeric_data, scale. = TRUE) # Scale the data for standardization

# Compute the proportion of variance explained
explained_variance <- (pca_result$sdev^2) / sum(pca_result$sdev^2) * 100

# Cumulative variance explained
cumulative_variance <- cumsum(explained_variance)

# Create a scree plot
plot(
  explained_variance,
  type = "b",
  xlab = "Principal Components",
  ylab = "Percentage of Variance Explained",
  main = "Scree Plot",
  pch = 19,
  col = "blue"
)
abline(h = 10, col = "red", lty = 2) # Optional: threshold for significance
# Add cumulative variance interpretation (optional)
cat("Explained Variance by Principal Components:\n")
print(explained_variance)
cat("\nCumulative Variance:\n")
print(cumulative_variance)





#e) Construction a bi-plot for the iris data based on R programming and interpretion of the the results is given below:
  # Load the iris dataset
  data(iris)

# Perform PCA on the numerical columns of the iris dataset (excluding the Species column)
pca_result <- prcomp(iris[, 1:4], center = TRUE, scale. = TRUE)

# Plot the bi-plot
biplot(pca_result, main = "Bi-plot of Iris Data")

# Optionally, you can customize the plot with different colors for each species
library(ggplot2)
pca_data <- data.frame(pca_result$x, Species = iris$Species)

# Plot with ggplot2 for better customization
ggplot(pca_data, aes(PC1, PC2, color = Species)) +
  geom_point(size = 3) +
  labs(title = "PCA Bi-plot of Iris Data", x = "Principal Component 1", y = "Principal Component 2") +
  theme_minimal()


